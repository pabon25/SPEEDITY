<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Find documents here</title>
    <link rel="stylesheet" href="fontawesome-free-6.4.0-web/css/all.min.css" />
    <!-- components -->

    <link rel="stylesheet" href="styles/document.css" />
    <link rel="stylesheet" href="styles/responsive.css" />
    <link rel="stylesheet" href="styles/prod.css" />
    <!-- media query -->
    <style>
      body{
        background-image: url(assets/myback.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
      }
    .applyform  p{
      font-size: 0.9rem;

      }
    </style>
  </head>
  <body class>
    <nav>
      <div class="logo">
        <img src="assets/logo.jpg" alt="" />
      </div>
      <div class="menu">
        <h1>SPEEDITY MULTISERVICES LTD</h1>
        <div class="links">
          <button><a href="allproducts.php">Ibicuruzwa</a></button>
          <button><a href="apply.php">Kwiyandikisha</a></button>
          <button><a href="about.php">Abo turibo</a></button>
          <button><a href="login.php">Injira muri konti</a></button>
          <button><a href="logout.php">Gusohoka</a></button>
        </div>
      </div>
    </nav>
    <section class="container main-home">
      <form action="applyform.php" method="post">
      <div class="applyform">
      <img src="assets/product.jpg" alt="">
       <center> <h1>SPEEDITY MULTISERVICES LTD</h1>
        <p>Multiservice company iherereye mu karere ka Kirehe,umurenge wa kirehe. </p>
        <p>Nyirayo ni Mauricei.dutanga amahugurwa mu bw'ubatsi n'ubusudizi.</p>
        <p>Tugurisha ibikoresho byo gusudira ,ikora ibikoresha bitandukanye byo mubyuma.</p>
        <p>Abifuza serivisi zacu mwaduhamagara kuri: 0784584996</p>
        <p>Mwanatwandikira kuri imeli ukurikira:mouricemultiservice25@gmail.com</p><center>

      </div>
      </form>
    </section>
    <footer>
      <div class="follow">
        <h1>Aho wadushakira</h1>
      <i class='fa fa-phone"' style="color:white;"></i>
       <i class="fa fa-phone" aria-hidden="true"style="color:white;"></i><b> 0784584996</b>
       <i class="fa fa-envelope" aria-hidden="true" style="color:white;"> </i><b> mouricemultiservice25@gmail.com</b>
    <i class="fa fa-map" aria-hidden="true"  style="color:white;"></i><b>Kirehe-Kirehe</b>
        <i class="fas fa-copyright"aria-hidden="true" style="color:white;"></i> <b>All copyright reserved to Speedity Multiservices Ltd
      </div>
    </footer>
  </body>
</html>
