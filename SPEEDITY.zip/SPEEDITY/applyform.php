<?php
$conn = mysqli_connect("localhost", "root", "", "speedity");
if ($_POST) {
   $name=$_POST['names'];
   $gender=$_POST['gender'];
   $dis=$_POST['dis'];
   $sec=$_POST['sec'];
   $aka=$_POST['aka'];
   $umu=$_POST['umu'];
   $tel=$_POST['tel'];
    $uku=$_POST['uku'];
   $noyuk=$_POST['noyuku'];
   $idno=$_POST['idno'];
   $dat=$_POST['dat'];
   $ubum=$_POST['ubum'];
   $hita=$_POST['hita'];

  $insert = mysqli_query($conn, "INSERT INTO `apply`(`fullnames`,`gender`, `district`, `sector`, `cell`, `village`, `tel`, `guider`, `guiderno`, `idno`, `birthdate`, `Ubumuga`, `level`) VALUES
   ('$name','$gender','$dis','$sec','$aka','$umu','$tel','$uku','$noyuk','$idno','$dat','$ubum','$hita')");
            header("location:allproducts.php");
            echo "<script>alert('application made');</script>";
        } else {
            echo "<script>alert('no application made');</script>";
            header("location:apply.php");
           
}



?>