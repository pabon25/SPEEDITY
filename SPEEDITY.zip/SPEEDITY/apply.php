<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Find documents here</title>
    <link rel="stylesheet" href="fontawesome-free-6.4.0-web/css/all.min.css" />
    <!-- components -->

    <link rel="stylesheet" href="styles/document.css" />
    <link rel="stylesheet" href="styles/responsive.css" />
    <link rel="stylesheet" href="styles/prod.css" />
    <!-- media query -->
    <style>
      body{
        background-image: url(assets/myback.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
      }
    </style>
  </head>
  <body class>
    <nav>
      <div class="logo">
        <img src="assets/logo.jpg" alt="" />
      </div>
      <div class="menu">
        <h1>SPEEDITY MULTISERVICES LTD</h1>
        <div class="links">
          <button><a href="allproducts.php">Ibicuruzwa</a></button>
          <button><a href="apply.php">Kwiyandikisha</a></button>
          <button><a href="about.php">Abo turibo</a></button>
          <button><a href="login.php">Injira muri konti</a></button>
          <button><a href="logout.php">Gusohoka</a></button>
        </div>
      </div>
    </nav>
    <section class="container main-home">
      <form action="applyform.php" method="post">
      <div class="applyform">
        <h2>Ifishi yuzurizwamo amakuru kubasaba kwitabira amahugurwa
           y'amezi atandatu muri SPEEDITY MULTISERVICES LTD kunkunga ya NEET Na RTB</h2>
           <label for="">Amazina yombi</label>
           <input type="text" name="names" id="" placeholder="Andika yawe amazina yombi" minlength="3">
           <label for="">Igitsina</label>
           <input type="radio" name="gender" value="Gore"><p style="margin-left: 15rem;" required><b>Gore</b></p>
           <input type="radio" name="gender" value="Gabo"><p style="margin-left: 15rem;"required><b>Gabo</b></p>
           <label for="">Akarere</label>
           <input type="text" name="dis" placeholder="Andika akarere utuyemo" required>
           <label for="">Umurenge</label>
           <input type="text" name="sec" placeholder="Andika umurenge utuyemo"required>
           <label for="">Akagari</label>
           <input type="text" name="aka" placeholder="Andika akagari utuyemo"required>
           <label for="">Umudugudu</label>
           <input type="text" name="umu" placeholder="Andika umudugudu utuyemo"required>
           <label for="">Nimero ya telefone yawe</label>
           <input type="text" name="tel" placeholder="Andika nimero ya telefone yawe" minlength="10" maxlength="10" title="Andika imibare 10">
           <label for="">Ukurera</label>
           <input type="text" name="uku" placeholder="Andika ukurera" required>
           <label for="">Nimero ya telefone y'ukurera</label>
           <input type="text" name="noyuku" placeholder="Andika nimero ya telefone y'ukurera" minlength="10" maxlength="10" title="Andika imibare 10">
           <label for="">Nimero y'indangamuntu</label>
           <input type="text"name="idno"placeholder="Andika nimero y'indangamuntu yawe" required     minlength="16" maxlength="16" title="Andika imibare 16">
           <label for="">Itariki y'amavuko</label>
           <input type="date" name="dat" id="" required>
           <label for="">Ufite ubumuga</label>
           <input type="radio" name="ubum" value="Yego" require><b>
            <p style="margin-left: 15rem;">Yego</p></b>
           <input type="radio" name="ubum" value="Oya" require>
           <b><p style="margin-left: 15rem;">Oya</p></b>
           <label for="">Hitamo icyiciro cy'amashuri wize</label>
           <select name="hita" id="" required>
            <option value="">Hitamo</option>
            <option value="Sinize">Sinize</option>
            <option value="Nize amashuri abanza">Nize amashuri abanza</option>
            <option value="Sinayasoje amashuri abanza">Nize amashuri abanza ariko sinayasoje</option>
             <option value="Sinagisoje amashuri yisumbuye">
                Nize amashuri y'isumbuye ariko sinagisoje</option>
                <option value="Nasoje amashuri yisumbuye">Nasoje amashuri y'isumbuye</option>
                <option value="Niga kaminuza">Niga kaminuza</option>
                <option value="Nasoje kaminuza">Nasoje kaminuza</option>
           </select>
           <button type="submit">Kohereza imyirondoro yawe</button>

      </div>
      </form>
    </section>
    <footer>
      <div class="follow">
        <h1>Aho wadushakira</h1>
      <i class='fa fa-phone"' style="color:white;"></i>
       <i class="fa fa-phone" aria-hidden="true"style="color:white;"></i><b> 0784584996</b>
       <i class="fa fa-envelope" aria-hidden="true" style="color:white;"> </i><b> mouricemultiservice25@gmail.com</b>
    <i class="fa fa-map" aria-hidden="true"  style="color:white;"></i><b>Kirehe-Kirehe</b>

        <i class="fas fa-copyright"aria-hidden="true" style="color:white;"></i> <b>All copyright reserved to Speedity Multiservices Ltd
      </div>
    </footer>
  </body>
</html>
