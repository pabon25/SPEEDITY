<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Find documents here</title>
    <link rel="stylesheet" href="fontawesome-free-6.4.0-web/css/all.min.css" />
    <!-- components -->

    <link rel="stylesheet" href="styles/document.css" />
    <link rel="stylesheet" href="styles/responsive.css" />
    <link rel="stylesheet" href="styles/prod.css" />
    <!-- media query -->
    <style>
      body{
        background-image: url(assets/myback.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
      }
    </style>
  </head>
  <body class>
    <nav>
      <div class="logo">
        <img src="assets/logo.jpg" alt="" />
      </div>
      <div class="menu">
        <h1>SPEEDITY MULTISERVICES LTD</h1>
        <div class="links">
        <button><a href="allproducts.php">Ibicuruzwa</a></button>
          <button><a href="apply.php">Kwiyandikisha</a></button>
          <button><a href="about.php">Abo turibo</a></button>
          <button><a href="logout.php">Gusohoka</a></button>
          <button><a href="products.php">Ongeraho</a></button>
        </div>
      </div>
    </nav>
    <section class="container main-home">
      <table border="2">
        <tr>
          <th>No</th>
          <th>Fullnames</th>
          <th>Igitsina</th>
          <th>Akarere</th>
          <th>Umurenge</th>
          <th>Akagari</th>
          <th>Umudugudu</th>
          <th>Telefone</th>
          <th>Umurera</th>
          <th>Telefone y'umurera</th>
          <th>Nimero y'indangamuntu</th>
          <th>Itariki y'amavuko</th>
          <th>Afite ubumuga</th>
          <th>Amashuri yize</th>
          <!-- <th colspan="4">Ibikorwa</th> -->
        </tr>
        <?php
                $conn=mysqli_connect("localhost","root","","speedity");
                if($conn){
                    $select = mysqli_query($conn,"SELECT * FROM `apply`");
                    while($row=mysqli_fetch_object($select)){
                        echo"<tr>
                        <td>$row->id</td>
                        <td>$row->fullnames</td>
                        <td>$row->gender</td>
                        <td>$row->district</td>
                        <td>$row->sector</td>
                        <td>$row->cell</td>
                        <td>$row->village</td>
                        <td>$row->tel</td>
                        <td>$row->guider</td>
                        <td>$row->guiderno</td>
                        <td>$row->idno</td>
                        <td>$row->birthdate</td>
                        <td>$row->Ubumuga</td>
                        <td>$row->level</td>
                       
                        
                        
                         </tr>";
                        
                    }
                   
                }
                echo "</table>";
                ?>

      
    </section>
    <footer>
      <div class="follow">
        <h1>Aho wadushakira</h1>
      <i class='fa fa-phone"' style="color:white;"></i>
       <i class="fa fa-phone" aria-hidden="true"style="color:white;"></i><b> 0784584996</b>
       <i class="fa fa-envelope" aria-hidden="true" style="color:white;"> </i><b> mouricemultiservice25@gmail.com</b>
    <i class="fa fa-map" aria-hidden="true"  style="color:white;"></i><b>Kirehe-Kirehe</b>
        <i class="fas fa-copyright"aria-hidden="true" style="color:white;"></i> <b>All copyright reserved to Speedity Multiservices Ltd
      </div>
    </footer>
  </body>
</html>
