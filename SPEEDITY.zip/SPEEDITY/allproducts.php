<?php
session_start();
?>
<?php

$conn = mysqli_connect('localhost', 'root', '', 'speedity');
$sql = "SELECT * FROM `products`" ;
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Find documents here</title>
    <link rel="stylesheet" href="fontawesome-free-6.4.0-web/css/all.min.css" />
    <!-- components -->

    <link rel="stylesheet" href="styles/document.css" />
    <link rel="stylesheet" href="styles/responsive.css" />
    <link rel="stylesheet" href="styles/products.css" />
    <!-- media query -->
    <!-- <style>
      body{
        background-image: url(assets/myback.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
      }
    </style> -->
  </head>
  <body class>
    <nav>
      <div class="logo">
        <img src="assets/logo.jpg" alt="" />
      </div>
      <div class="menu">
        <h1>SPEEDITY MULTISERVICES LTD</h1>
        <div class="links">
          <button><a href="allproducts.php">Ibicuruzwa</a></button>
          <button><a href="apply.php">Kwiyandikisha</a></button>
          <button><a href="about.php">Abo turibo</a></button>
          <button><a href="login.php">Injira muri konti</a></button>
          <button><a href="logout.php">Gusohoka</a></button>
        </div>
      </div>
    </nav>
    <div class="titlep" >
        <button><a href="apply.php">Iyandikishe</a></button>
              <h2>Ibicuruzwa bihari</h2> 
        </div>
    <section class="container main-home">
    
      <div class="displayproducts">
        
                <?php
                if (mysqli_num_rows($result) < 1) {
                    echo "no records found";
                } else {
                    while ($product = mysqli_fetch_object($result)) {
                        ?>
                        <div class="myproducts">
                                <img height="150" src="uploads/<?php print $product->image;?>" alt="">
                              <!-- <button style="margin-left: 2rem;"><a href="verify.php">verify</a></button> -->
                              <center>  
                                    <p style="font-size: 1rem;">Izina ry'igicuruzwa:<b><?php print $product->name;?></b></p>
                                    <p style="font-size: 1rem;">Igiciro cy'igicuruzwa:<b><?php print $product->price;?></b></p>
                                    <p style="font-size: 1rem;">Hamagara:<b>07890989830</b></p>
                                  </center>
                                  
               </div>

                        <?php
                    }
                }
                ?>
       </div>

  </body>
</html>
