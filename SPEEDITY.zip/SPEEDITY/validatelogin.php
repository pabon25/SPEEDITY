<?php
session_start();
?><?php
$conn = mysqli_connect("localhost", "root", "", "speedity");

if (isset($_POST)) {
    $email = $_POST['email'];
    $pswd = $_POST['password'];
    $select = mysqli_query($conn, "SELECT * FROM `users` WHERE `email`='$email' AND `password`='$pswd'");
    if (mysqli_num_rows($select) > 0) {
       
            $_SESSION["email"] = $row['email'];
            $_SESSION["pswd"] =$row['password'];
                header("location:showapplicant.php");
    }
             else {
              echo"<script>alter('mwakoresheje imeli cyangwa ijambobanga bitaribyo');</script>";
                header("location:login.php");
            }
    
}
?>
