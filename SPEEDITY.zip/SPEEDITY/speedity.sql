-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2023 at 09:56 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `speedity`
--

-- --------------------------------------------------------

--
-- Table structure for table `apply`
--

CREATE TABLE `apply` (
  `id` int(255) NOT NULL,
  `fullnames` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `sector` varchar(255) NOT NULL,
  `cell` varchar(255) NOT NULL,
  `village` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `guider` varchar(255) NOT NULL,
  `guiderno` varchar(11) NOT NULL,
  `idno` varchar(255) NOT NULL,
  `birthdate` date NOT NULL DEFAULT current_timestamp(),
  `Ubumuga` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `apply`
--

INSERT INTO `apply` (`id`, `fullnames`, `gender`, `district`, `sector`, `cell`, `village`, `tel`, `guider`, `guiderno`, `idno`, `birthdate`, `Ubumuga`, `level`) VALUES
(11, '', '', 'Rubavu', 'Rubavu', 'gikombe', 'bushengo', '0790989830', 'MUKAMUGANGA Christine', '790989830', '1234567890', '2023-10-29', 'Yego', 'Sinize'),
(12, 'kwi', 'Gore', 'kk', 'kkk', 'll', 'kk', '00', 'll', '0', '0000', '0000-00-00', 'Oya', 'Nize amashuri abanza'),
(13, 'KWIZERA Isezerano', 'Gore', 'Rubavu', 'Rubavu', 'gikombe', 'bushengo', '0790989830', 'MUKAMUGANGA Christine', '790989830', '1234567890', '2023-10-25', 'Yego', 'Sinize'),
(14, 'MANISHIMWE Patrick', 'Gabo', 'MUHANGA', 'MUHANGA', 'MUHANGA', 'MUHANGA', '0783180795', 'NSHIMIYIMANA Elia', '790989830', '1234567890', '2023-10-10', 'Oya', 'Nasoje kaminuza'),
(15, 'jj', 'Gore', 'nn', 'm', 'MUHANGA', 'MUHANGA', '0783180795', 'NSHIMIYIMANA Elia', '790989830', '1234567890', '2023-10-12', 'Oya', 'Nize amashuri abanza'),
(16, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(17, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(18, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(19, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(20, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(21, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(22, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(23, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(24, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(25, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(26, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(27, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(28, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(29, '', '', '', '', '', '', '', '', '0', '', '0000-00-00', '', ''),
(30, 'kwizera', '', '', '', '', '', '', '', '', '', '0000-00-00', '', 'Sinize'),
(31, 'aaa', 'Gore', 'a', 'a', 'a', 'a', '9999999999', 'a', '9999999999', '9999999999999999', '2023-10-29', 'Yego', 'Sinize'),
(32, 'aaa', 'Gore', 'a', 'a', 'a', 'a', '9999999999', 'a', '9999999999', '9999999999999999', '2023-10-29', 'Yego', 'Nize amashuri abanza'),
(33, 'aaa', 'Gore', 'a', 'a', 'a', 'a', '9999999999', 'a', '9999999999', '9999999999999999', '2023-10-29', 'Yego', 'Sinayasoje amashuri abanza'),
(34, 'aaa', 'Gore', 'a', 'a', 'a', 'a', '9999999999', 'a', '9999999999', '9999999999999999', '2023-10-29', 'Yego', 'Sinagisoje amashuri yisumbuye'),
(35, 'aaa', 'Gore', 'a', 'a', 'a', 'a', '9999999999', 'a', '9999999999', '9999999999999999', '2023-10-29', 'Yego', 'Nasoje amashuri yisumbuye'),
(36, 'kwizera', '', '', '', '', '', '', '', '', '', '0000-00-00', '', 'Niga kaminuza'),
(37, 'kwizera', 'Gabo', 'w', 'kkk', 'll', 'kk', '0000000000', 'll', '0000000000', '0000', '2023-10-29', 'Yego', 'Nasoje kaminuza');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(1, 'dell', '$500', 'PSX_20231028_231449.jpg'),
(2, 'dell', '$600', '1.PNG'),
(3, 'pc', '300', 'gm.png'),
(4, 'pc', '300', 'gm.png'),
(5, 'pc', '300', 'gm.png'),
(6, 'iphone', '$700', 's11.jpg'),
(7, 'tv', '$700', 'tv1.jpg'),
(8, 'machine', '$300', '2 - Copy.png'),
(9, 'kk', '$300', '2 - Copy.png'),
(10, 'kk', '500', 'images (1).jfif');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(30) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `email`, `password`) VALUES
(1, 'Maurice', 'mauricemultiservice25@gmail.com', 'maurice@speedity123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apply`
--
ALTER TABLE `apply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apply`
--
ALTER TABLE `apply`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
