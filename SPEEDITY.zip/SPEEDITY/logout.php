<?php
session_start();
?>
<?php
// echo $_SESSION["user"];
unset($_SESSION["email"]);
unset($_SESSION["pswd"]);
session_destroy();
header("location:login.php");

?>