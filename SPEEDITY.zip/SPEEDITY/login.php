
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Find documents here</title>
    <link rel="stylesheet" href="fontawesome-free-6.4.0-web/css/all.min.css" />
    <!-- components -->

    <link rel="stylesheet" href="styles/document.css" />
    <link rel="stylesheet" href="styles/responsive.css" />
    <link rel="stylesheet" href="styles/products.css" />

    <!-- media query -->
    <style>
      body{
        background-image: url(assets/myback.jpg);
        background-repeat: repeat;
        background-size: cover;
        background-position: center;
      }
    </style>
  </head>
  <body class>
    <nav>
      <div class="logo">
        <img src="assets/logo.jpg" alt="" />
      </div>
      <div class="menu">
        <h1>SPEEDITY MULTISERVICES LTD</h1>
        <div class="links">
        <button><a href="allproducts.php">Ibicuruzwa</a></button>
          <button><a href="apply.php">Kwiyandikisha</a></button>
          <button><a href="about.php">Abo turibo</a></button>
          <button><a href="login.php">Injira muri konti</a></button>
        </div>
      </div>
    </nav>
    <section class="container main-home">
      <div class="pform">
        <h1 align="center">Uzuza amakuru y'akonti yawe</h1><br><br>
        <!-- <div class="advert"> -->
        <form action="validatelogin.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="">Imeri ukoresha winjira muri konti yawe</label>
                <input type="text" name="email" id="" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="">Ijambobanga ukoresha winjira muri konti yawe</label>
                <input type="text" name="password" id="" class="form-control" required>
            </div>
            <div class="form-group mt-2">
                <button type="submit" class="btn btn-primary w-100">Injira</button>
            </div>
        </form>
    </section>
    <footer>
      <div class="follow">
        <h1>Aho wadushakira</h1>
      <i class='fa fa-phone"' style="color:white;"></i>
       <i class="fa fa-phone" aria-hidden="true"style="color:white;"></i><b> 0784584996</b>
       <i class="fa fa-envelope" aria-hidden="true" style="color:white;"> </i><b> mouricemultiservice25@gmail.com</b>
        <i class="fas fa-copyright"aria-hidden="true" style="color:white;"></i> <b>All copyright reserved to Speedity Multiservices Ltd
      </div>
    </footer>
  </body>
</html>
