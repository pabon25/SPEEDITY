<?php
$conn = mysqli_connect("localhost", "root", "", "speedity");
if ($_POST) {
    if (isset($_FILES['pfile'])) {
        $image = $_FILES['pfile'];
        $pimage = $image['name'];
        $tmp = $image['tmp_name'];
        $target_dir = "uploads/" . $pimage;

        if (move_uploaded_file($tmp, "uploads/" . $pimage)) {
            $insert = mysqli_query($conn, "INSERT INTO `annouce`(`announce`) VALUES ('$pimage')");
            // Redirect to some page after successful upload
            header("location:announcement.php");
        }
        else {
            echo "<script>alert('product is successfully inserted');</script>";
           
        }
    } else {
        echo "<script>alert('Image is required');</script>";
    }

}
?>
