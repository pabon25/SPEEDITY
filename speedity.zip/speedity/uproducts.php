<?php
$conn = mysqli_connect("localhost", "root", "", "speedity");
if ($_POST) {
    $pname = $_POST['pname'];
    $price=$_POST['price'];
   $type=$_POST['types'];
    if (isset($_FILES['pfile'])) {
        $image = $_FILES['pfile'];
        $pimage = $image['name'];
        $tmp = $image['tmp_name'];
        $target_dir = "uploads/" . $pimage;

        if (move_uploaded_file($tmp, $target_dir)) {
            $insert = mysqli_query($conn, "INSERT INTO `products`(`name`, `price`, `image`) VALUES
             ('$pname','$price','$pimage')");
            header("location:allproducts.php");
        } else {
            echo "<script>alert('product is successfully inserted');</script>";
           
        }
    } else {
        echo "<script>alert('Image is required');</script>";
    }

}
?>
