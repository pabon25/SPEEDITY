<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Find documents here</title>
    <link rel="stylesheet" href="fontawesome-free-6.4.0-web/css/all.min.css" />
    <!-- components -->

    <link rel="stylesheet" href="styles/document.css" />
    <link rel="stylesheet" href="styles/responsive.css" />
    <link rel="stylesheet" href="styles/products.css" />
    <!-- media query -->
    <!-- <style>
      body{
        background-image: url(assets/myback.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
      }
    </style> -->
  </head>
<body>
<nav>
      <div class="logo">
        <img src="assets/logo.jpg" alt="" />
      </div>
      <div class="menu">
        <h1>SPEEDITY MULTISERVICES LTD</h1>
        <div class="links">
          <button><a href="allproducts.php">Ibicuruzwa</a></button>
          <button><a href="apply.php">Kwiyandikisha</a></button>
          <button><a href="about.php">Abo turibo</a></button>
          <button><a href="login.php">Injira muri konti</a></button>
          <button><a href="logout.php">Gusohoka</a></button>
        </div>
      </div>
    </nav>
    <section class="container uploaded-files">
        <h2>Uploaded Announcements</h2>
        <div class="files-list">
            <?php

            $conn = mysqli_connect("localhost", "root", "", "speedity");
            $fetch_files = mysqli_query($conn, "SELECT * FROM `annouce`");
            while ($row = mysqli_fetch_assoc($fetch_files)) {
                $file_name = $row['announce'];
                echo "<a href='uploads/$file_name' target='_blank'>$file_name</a><br>";
            }
            ?>
        </div>
    </section>
    <footer>
      <div class="follow">
        <h1>Aho wadushakira</h1>
      <i class='fa fa-phone"' style="color:white;"></i>
       <i class="fa fa-phone" aria-hidden="true"style="color:white;"></i><b> 0784584996</b>
       <i class="fa fa-envelope" aria-hidden="true" style="color:white;"> </i><b> mouricemultiservice25@gmail.com</b>
    <i class="fa fa-map" aria-hidden="true"  style="color:white;"></i><b>Kirehe-Kirehe</b>
        <i class="fas fa-copyright"aria-hidden="true" style="color:white;"></i> <b>All copyright reserved to Speedity Multiservices Ltd
      </div>
    </footer>
  
</body>
</html>
